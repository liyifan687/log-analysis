package hive;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat;
import org.apache.hadoop.hbase.mapreduce.TableReducer;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;


public class testimport extends Configured{
	public static void main(String[] args) throws Exception{
		Configuration conf = HBaseConfiguration.create();
        conf.set("hbase.zookeeper.quorum", "Master:2181");
        conf.set("hbase.rootdir", "hdfs://Master:8020/hbase");
        //�������hbase�ı�
        conf.set(TableOutputFormat.OUTPUT_TABLE, "log1");//hbase�б���
        Job job = new Job(conf, testimport.class.getSimpleName());       
        
        job.setJarByClass(testimport.class);
        
        job.setMapperClass(map.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        
        job.setReducerClass(reducer.class);
        
        FileInputFormat.addInputPath(job, new Path("hdfs://Master:8020/data/access_2013_05_30.log"));
        job.setOutputFormatClass(TableOutputFormat.class);
        job.waitForCompletion(true);
	}
	
	static class map extends Mapper<LongWritable, Text, Text, Text>{
		LogParser logParser = new LogParser();
		Text k = new Text();
		Text v = new Text();
		
		@Override
		protected void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
		final String[] parsed = logParser.parse(value.toString());
			//���˵���̬��Ϣ
			if(parsed[2].startsWith("GET /static/") || parsed[2].startsWith("GET /uc_server")){
				return;
			}
			//������ͷ���ض���ʽ�ַ���
			if(parsed[2].startsWith("GET /")){
				parsed[2] = parsed[2].substring("GET /".length());
			}
			else if(parsed[2].startsWith("POST /")){
				parsed[2] = parsed[2].substring("POST /".length());
			}			
			//���˽�β���ض���ʽ�ַ���
			if(parsed[2].endsWith(" HTTP/1.1")){
				parsed[2] = parsed[2].substring(0, parsed[2].length()-" HTTP/1.1".length());
			}
			k.set(parsed[0]+"_"+parsed[1]);
			v.set(parsed[2]+"\t"+parsed[3]+"\t"+parsed[4]);
			context.write(k, v);
		}	
	}
	
	static class reducer extends TableReducer<Text, Text, NullWritable>{
		private Put add;

		@Override
		protected void reduce(Text k, Iterable<Text> vs,
				Context context)
				throws IOException, InterruptedException {
			Put put = new Put(k.getBytes());
			for (Text v : vs) {
				String[] splis = v.toString().split("\t");
                if(splis[0]!=null && !"NULL".equals(splis[0])){
                     put.add("cf1".getBytes(), "url".getBytes(),splis[0].getBytes());//������Դ����ַ��
                }
                if(splis[1]!=null && !"NULL".equals(splis[1])){
                    put.add("cf1".getBytes(), "status".getBytes(),splis[1].getBytes());//״̬�� 200
                }
                if(splis[2]!=null && !"NULL".equals(splis[2])){
                    put.add("cf1".getBytes(), "traffic".getBytes(),splis[2].getBytes());//��������
                }
                
			}
			context.write(NullWritable.get(),put);
		}	
	}
	
	static class LogParser {
        public static final SimpleDateFormat FORMAT = new SimpleDateFormat(
                "d/MMM/yyyy:HH:mm:ss", Locale.ENGLISH);
        public static final SimpleDateFormat dateformat1 = new SimpleDateFormat(
                "yyyyMMddHHmmss");
        private Date parseDateFormat(String string) {
            Date parse = null;
            try {
                parse = FORMAT.parse(string);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return parse;
        }        
        public String[] parse(String line) {
            String ip = parseIP(line);
            String time = parseTime(line);
            String url = parseURL(line);
            String status = parseStatus(line);
            String traffic = parseTraffic(line);

            return new String[] { ip, time, url, status, traffic };
        }

        private String parseTraffic(String line) {
            final String trim = line.substring(line.lastIndexOf("\"") + 1)
                    .trim();
            String traffic = trim.split(" ")[1];
            return traffic;
        }

        private String parseStatus(String line) {
            final String trim = line.substring(line.lastIndexOf("\"") + 1)
                    .trim();
            String status = trim.split(" ")[0];
            return status;
        }

        private String parseURL(String line) {
            final int first = line.indexOf("\"");
            final int last = line.lastIndexOf("\"");
            String url = line.substring(first + 1, last);
            return url;
        }

        private String parseTime(String line) {
            final int first = line.indexOf("[");
            final int last = line.indexOf("+0800]");
            String time = line.substring(first + 1, last).trim();
            Date date = parseDateFormat(time);
            return dateformat1.format(date);
        }

        private String parseIP(String line) {
            String ip = line.split("- -")[0].trim();
            return ip;
        }
    }
}