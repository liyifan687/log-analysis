package com.echart;

public class barBean {
	private String logdate;
	 private int pv;
	 private int zc;  
	 private int ip; 
	 private float bl; 
	 
	 
	 
	 public int getZc() {
		return zc;
	}
	public void setZc(int zc) {
		this.zc = zc;
	}
	public int getIp() {
		return ip;
	}
	public void setIp(int ip) {
		this.ip = ip;
	}
	public float getBl() {
		return bl;
	}
	public void setBl(float bl) {
		this.bl = bl;
	}
	
	
	public String getLogdate() {
		return logdate;
	}
	public void setLogdate(String logdate) {
		this.logdate = logdate;
	}
	public int getPv() {
		return pv;
	}
	public void setPv(int pv) {
		this.pv = pv;
	}
	
	    
}
